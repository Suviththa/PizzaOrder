import React from 'react'
import Navbar from './Navbar';


const Header= ()=>{
    return(
        <div className="banner">
            <Navbar/>
            <div className="banner__content">
                <div className="container">
                   <div className="banner__text">
                   <h3>Pizza Delivery</h3>
                    <h1>New Pizza World</h1>
                    <p>Welcome to our New Pizza World. Enjoy your self by ordering!.Let's order and feel happy!. Taste our variety of pizzas.</p>
                    <div className="banner__btn">
              <a href="" className="btn btn-smart">
                DEVLERY NOW
              </a>
            </div>

                   </div>
                   
                </div>
            </div>

        </div>
    )
}

export default Header;